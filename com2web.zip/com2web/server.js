// ====================== 1. 引入必要模組 ======================
const express = require('express');          // Web框架，搭建HTTP服務
const { SerialPort } = require('serialport'); // 串口通信庫，連接COM3
const cors = require('cors');                // 解決跨域（前端與後端不同源時需要）
const bodyParser = require('body-parser');   // 解析前端發送的JSON數據

// ====================== 2. 初始化服務配置 ======================
const app = express();
const PORT = 3000;                          // 服務監聽端口（可改為80/443等）
const COM_PORT = 'COM3';                    // 本地COM口（根據實際設備修改，如COM4）
const BAUD_RATE = 9600;                     // 串列傳輸速率（與設備一致，常見9600/115200）
const DATA_BITS = 8;                        // 數據位（常見8位）
const STOP_BITS = 1;                        // 停止位（常見1位）
const PARITY = 'none';                      // 校驗位（無校驗，常見none/even/odd）

// ====================== 3. 配置中間件 ======================
app.use(cors());                            // 允許跨域（前端網頁訪問必須）
app.use(bodyParser.json());                 // 解析前端發送的JSON格式請求體
app.use(express.static('public'));          // 託管前端靜態檔（HTML/CSS/JS存放在public目錄）

// ====================== 4. 初始化COM3串口 ======================
let serialPort; // 全局變數存儲串口實例

// 非同步函數：連接並初始化COM3串口
async function initSerialPort() {
  try {
    // 創建串口實例（參數必須與設備一致）
    serialPort = new SerialPort({
      path: COM_PORT,
      baudRate: BAUD_RATE,
      dataBits: DATA_BITS,
      stopBits: STOP_BITS,
      parity: PARITY
    });

    // 監聽串口數據（可選，用於接收設備回應並回顯）
    serialPort.on('data', (data) => {
      const response = data.toString('utf8').trim(); // 轉換為字串並去除空白
      console.log(`📥 設備回應: ${response}`); // 控制臺列印設備返回的數據
    });

    // 監聽串口錯誤（如斷開連接）
    serialPort.on('error', (err) => {
      console.error(`❌ 串口錯誤: ${err.message}`);
    });

    console.log(`✅ 端口${COM_PORT} 已成功連接，串列傳輸速率：${BAUD_RATE}`);
  } catch (err) {
    console.error(`❌ 串口連接失敗: ${err.message}`);
    process.exit(1); // 串口連接失敗時終止服務
  }
}

// 啟動串口連接（程式啟動時執行）
initSerialPort();

// ====================== 5. 定義API介面（接收前端命令） ======================
// 發送命令到COM3的介面（POST請求）
app.post('/api/send-command', async (req, res) => {
  try {
    // 1. 驗證請求參數（前端需發送{ "command": "命令內容" }）
    const { command } = req.body;
    if (!command) {
      return res.status(400).json({ 
        status: 'error', 
        message: '缺少command參數（請發送JSON格式：{ "command": "你的命令" }）' 
      });
    }

    // 2. 驗證串口是否已連接
    if (!serialPort || !serialPort.isOpen) {
      throw new Error('串口未連接，請重啟服務');
    }

    // 3. 發送命令到串口（根據設備協議添加結束符，如\r\n）
    const fullCommand = `${command}\r\n`; // 假設設備需要\r\n結束命令
    await serialPort.write(fullCommand); // 非同步寫入命令（確保發送完成）

    // 4. 記錄日誌並返回成功
    console.log(`📤 已發送命令: ${fullCommand.trim()}`); // 控制臺列印發送的命令
    res.json({ 
      status: 'success', 
      message: `命令已發送: ${command}` 
    });

  } catch (err) {
    // 錯誤處理（記錄日誌並返回錯誤資訊給前端）
    console.error(`❌ 發送失敗: ${err.message}`);
    res.status(500).json({ 
      status: 'error', 
      message: `命令發送失敗: ${err.message}` 
    });
  }
});

// ====================== 6. 啟動HTTP服務 ======================
app.listen(PORT, '0.0.0.0', () => {
  // 獲取本機局域網IP（用於遠程訪問）
  const getLocalIP = () => {
    const os = require('os');
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
      for (const iface of interfaces[name]) {
        if (iface.family === 'IPv4' && !iface.internal) { // 非內網IP
          return iface.address;
        }
      }
    }
    return 'localhost'; // 無局域網IP時返回本地地址
  };

  // 列印服務啟動資訊
  console.log(`🌐 服務已啟動，訪問地址：http://${getLocalIP()}:${PORT}`);
  console.log(`🔌 端口${COM_PORT} 已監聽，等待前端指令...`);
});