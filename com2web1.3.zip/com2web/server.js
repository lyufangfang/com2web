/**
 * COM转网页服务主入口文件（含登录验证、会话管理、未登录自动跳转、日志功能）
 */
const express = require('express');
const { SerialPort } = require('serialport');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs').promises;
const path = require('path');
const os = require('os');
const session = require('express-session');
const bcrypt = require('bcrypt');

// ====================== 1. 初始化服务配置 ======================
const app = express();
const DEFAULT_PORT = 3000;       // 默认服务端口
const DEFAULT_COM_PORT = 'COM3'; // 默认COM端口
const DEFAULT_BAUD_RATE = 9600;  // 默认波特率
const CONFIG_PATH = path.join(__dirname, 'config.json'); // 配置文件路径
const LOG_FILE = path.join(__dirname, 'system.log'); // 日志文件路径

// 全局配置对象（初始值）
let config = {
  servicePort: DEFAULT_PORT,    // 网页服务端口
  comPort: DEFAULT_COM_PORT,    // COM端口
  baudRate: DEFAULT_BAUD_RATE,  // 波特率
  isRunning: false              // 服务运行状态
};

// 预设管理员账户（生产环境建议从数据库或配置文件读取）
const ADMIN_USER = {
  username: 'admin',
  passwordHash: '$2b$10$O2RUYQp2YPLUIsIKKcFyR.Q7OTYR4Gjg2pFPGE3xZUgckWTG0w.4e' // "admin123"的bcrypt哈希值（盐轮数10）
};

// 会话配置（密钥需保密，生产环境建议从环境变量获取）
app.use(session({
  secret: 'your-strong-secret-key-here', // 替换为强随机字符串（如：openssl rand -hex 32）
  resave: false,                      // 不强制保存未修改的会话
  saveUninitialized: false,           // 不保存未初始化的会话
  cookie: { 
    secure: process.env.NODE_ENV === 'production', // 生产环境启用HTTPS时设为true
    maxAge: 24 * 60 * 60 * 1000       // 会话有效期24小时（毫秒）
  }
}));

// 允许跨域（解决前端跨域问题）
app.use(cors({
  origin: '*', // 允许所有源（开发环境推荐）
  credentials: true // 允许携带Cookie（关键！）
}));

// 解析JSON请求体（用于API接口）
app.use(bodyParser.json({ limit: '10mb' }));

// 托管管理界面静态资源（HTML/CSS/JS）
app.use(express.static('public'));

// ====================== 2. 日志记录模块 ======================
/**
 * 获取本地时间戳（格式：YYYY-MM-DD HH:mm:ss）
 */
function getLocalTimestamp() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

/**
 * 记录日志（格式：[时间] [级别] [IP:xxx.xxx.xxx.xxx] 消息）
 * @param {string} level 日志级别（info/error/warning）
 * @param {string} message 日志消息
 * @param {Object} req 请求对象（用于获取用户IP）
 */
async function log(level, message, req) {
  const timestamp = getLocalTimestamp(); // 使用本地时间戳
  const ip = req?.ip?.replace('::ffff:', '') || '未知IP';
  const logEntry = `[${timestamp}] [${level}] [IP:${ip}] ${message}\n`;
  
  try {
    await fs.appendFile(LOG_FILE, logEntry);
  } catch (err) {
    console.error('写入日志失败:', err);
  }
}

// ====================== 3. 登录验证中间件 ======================
/**
 * 检查用户是否已登录（未登录则重定向到登录页）
 */
function checkAuth(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/admin/login'); // 未登录，重定向到登录页
  }
  next(); // 已登录，继续执行
}

// ====================== 4. 核心API接口 ======================
/**
 * 获取当前服务配置
 * 路径：GET /api/config
 */
app.get('/api/config', (req, res) => {
  res.json({ 
    success: true, 
    config: {
      servicePort: config.servicePort,
      comPort: config.comPort,
      baudRate: config.baudRate,
      isRunning: config.isRunning
    } 
  });
});

/**
 * 保存服务配置（COM端口/波特率/网页端口）
 * 路径：POST /api/config
 */
app.post('/api/config', async (req, res) => { // 改为async函数
  try {
    const { comPort, baudRate, servicePort } = req.body;
    
    // 更新配置（仅允许修改允许的字段）
    if (comPort) config.comPort = comPort;
    if (baudRate) config.baudRate = parseInt(baudRate);
    if (servicePort) config.servicePort = parseInt(servicePort);

    // 保存配置到文件（使用await等待完成）
    await fs.writeFile(CONFIG_PATH, JSON.stringify(config, null, 2));
    log('info', `配置已保存：${JSON.stringify(config)}`, req);
    
    // 统一发送成功响应（仅一次）
    res.json({ success: true, message: '配置保存成功' });
  } catch (err) { // 集中捕获所有错误
    log('error', `保存配置失败: ${err.message}`, req);
    res.status(500).json({ success: false, message: '保存配置失败' }); // 仅发送一次响应
  }
});

/**
 * 控制服务启停（启动/停止）
 * 路径：POST /api/service/:action(start|stop)
 */
app.post('/api/service/:action(start|stop)', async (req, res) => { // 改为async函数
  try {
    const action = req.params.action;
    
    if (action === 'start') {
      // 启动服务前先连接串口（等待连接完成）
      const connected = await connectSerial();
      if (!connected) throw new Error('串口连接失败');
      
      config.isRunning = true;
      startCommandServer(); // 启动命令接收服务
      log('info', '服务已启动', req);
      res.json({ success: true, message: '服务已启动' });
    } else {
      // 停止服务前断开串口（等待断开完成）
      await disconnectSerial();
      config.isRunning = false;
      stopCommandServer(); // 停止命令接收服务
      log('info', '服务已停止', req);
      res.json({ success: true, message: '服务已停止' });
    }
  } catch (err) {
    log('error', `服务控制失败: ${err.message}`, req);
    res.status(500).json({ success: false, message: err.message }); // 仅发送一次响应
  }
});

/**
 * 发送串口命令（需服务已启动）
 * 路径：POST /api/send-command
 */
app.post('/api/send-command', async (req, res) => { // 改为async函数
  try {
    const { command } = req.body;
    if (!command) {
      return res.status(400).json({ 
        status: 'error', 
        message: '缺少command参数（请发送JSON格式：{ "command": "你的命令" }）' 
      });
    }

    if (!isSerialConnected) {
      throw new Error('串口未连接，请先启动服务');
    }

    const fullCommand = `${command}\r\n`; // 添加换行符（常见串口指令格式）
    serialPort.write(fullCommand);
    log('info', `已发送命令: ${command}`, req);
    res.json({ status: 'success', message: `命令已发送: ${command}` });
  } catch (err) {
    log('error', `命令发送失败: ${err.message}`, req);
    res.status(500).json({ status: 'error', message: `命令发送失败: ${err.message}` }); // 仅发送一次响应
  }
});

/**
 * 获取系统可用COM端口列表（用于管理界面扫描）
 * 路径：GET /api/ports
 */
app.get('/api/ports', async (req, res) => {
  try {
    const ports = await SerialPort.list(); // 调用系统API获取COM端口列表
    const portPaths = ports.map(port => port.path); // 提取端口路径（如 "COM3"）
    res.json({ success: true, ports: portPaths });
  } catch (err) {
    log('error', `获取COM端口失败: ${err.message}`, req);
    res.status(500).json({ success: false, message: '获取COM端口失败' }); // 仅发送一次响应
  }
});

/**
 * 检查登录状态接口（返回JSON）
 * 路径：GET /api/check-login
 */
app.get('/api/check-login', (req, res) => {
  res.json({ loggedIn: !!req.session.user }); // 返回是否已登录
});

// ====================== 5. 日志查询接口 ======================
/**
 * 获取最近日志接口（返回JSON）
 * 路径：GET /api/logs
 * 参数：?limit=100（限制返回最近100条）
 */
app.get('/api/logs', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 100; // 默认返回100条
    // 读取日志文件内容
    const data = await fs.readFile(LOG_FILE, 'utf8');
    // 按行分割，并过滤空行
    const lines = data.split('\n').filter(line => line.trim() !== '');
    // 取最近的limit条
    const recentLogs = lines.slice(-limit); 
    res.json({ success: true, logs: recentLogs });
  } catch (err) {
    // 日志文件不存在时返回空数组
    if (err.code === 'ENOENT') {
      res.json({ success: true, logs: [] });
    } else {
      log('error', `读取日志失败: ${err.message}`, req);
      res.status(500).json({ success: false, message: '读取日志失败' }); // 仅发送一次响应
    }
  }
});

// ====================== 6. 登录/注销接口 ======================
// 登录页面（返回HTML表单）
app.get('/admin/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin', 'login.html'));
});

/**
 * 处理登录请求（POST）
 * 改为async函数避免回调嵌套
 */
app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    // 验证用户名是否存在（必须等于 'admin'）
    if (username !== ADMIN_USER.username) {
      return res.status(401).json({ success: false, message: '用户名或密码错误' });
    }

    // 验证密码哈希（比较用户输入的密码与存储的哈希值）
    const isPasswordValid = await bcrypt.compare(password, ADMIN_USER.passwordHash);
    if (!isPasswordValid) {
      return res.status(401).json({ success: false, message: '用户名或密码错误' });
    }

    // 登录成功，设置会话（标记用户已登录）
    req.session.user = { username: ADMIN_USER.username };
    log('info', `用户 ${username} 登录成功`, req);
    res.json({ success: true, message: '登录成功' });

  } catch (err) {
    log('error', `登录失败: ${err.message}`, req);
    res.status(500).json({ success: false, message: '服务器错误' }); // 仅发送一次响应
  }
});

// 注销接口（销毁会话）
app.post('/api/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      log('error', `注销失败: ${err.message}`, req);
      return res.status(500).json({ success: false, message: '注销失败' });
    }
    log('info', '用户已注销', req);
    res.json({ success: true, message: '注销成功' });
  });
});

// ====================== 7. 路由保护（未登录自动跳转） ======================
// 管理后台路由实例（所有 /admin 路由需保护）
const adminRouter = express.Router();

// 示例：管理后台的 API 路由（需保护）
adminRouter.get('/status', (req, res) => { 
  res.json({ status: config.isRunning ? '运行中' : '已停止' }); 
});

adminRouter.post('/save-config', (req, res) => { 
  res.json({ success: true, message: '配置保存成功' });
});

// 应用中间件：除登录页外，所有 /admin 路由需先检查登录状态
app.use('/admin', (req, res, next) => {
  // 排除登录页（/admin/login）的中间件检查
  if (req.path === '/admin/login') {
    return next();
  }
  // 其他 /admin 路由需检查登录状态
  checkAuth(req, res, next);
});

// 挂载管理后台路由
app.use('/admin', adminRouter);

// ====================== 8. 串口管理工具函数 ======================
let serialPort;       // 全局串口实例
let isSerialConnected = false; // 串口连接状态标志

/**
 * 连接串口（根据当前配置）
 */
async function connectSerial() {
  try {
    if (serialPort && isSerialConnected) {
      await disconnectSerial(); // 先关闭已有连接
    }

    // 创建串口实例（使用当前配置的COM端口和波特率）
    serialPort = new SerialPort({
      path: config.comPort,
      baudRate: config.baudRate,
      dataBits: 8,
      stopBits: 1,
      parity: 'none',
      autoOpen: false // 手动打开连接
    });

    // 打开串口连接（等待完成）
    await new Promise((resolve, reject) => {
      serialPort.open((err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    // 监听串口数据（接收设备回传数据）
    serialPort.on('data', (data) => {
      const response = data.toString('utf8').trim();
      console.log(`📥 设备回传数据: ${response}`);
      log('info', `串口数据: ${response}`); // 仅记录日志，不发送响应
    });

    // 监听串口错误（仅记录日志，不发送响应）
    serialPort.on('error', (err) => {
      console.error(`❌ 串口错误: ${err.message}`);
      isSerialConnected = false;
      log('error', `串口错误: ${err.message}`);
    });

    isSerialConnected = true;
    console.log(`✅ 串口 ${config.comPort} 连接成功（波特率：${config.baudRate}）`);
    return true;
  } catch (err) {
    console.error(`❌ 串口连接失败: ${err.message}`);
    isSerialConnected = false;
    log('error', `串口连接失败: ${err.message}`);
    return false;
  }
}

/**
 * 断开串口连接
 */
async function disconnectSerial() {
  if (serialPort && isSerialConnected) {
    await new Promise((resolve, reject) => {
      serialPort.close((err) => {
        if (err) reject(err);
        else resolve();
      });
    });
    isSerialConnected = false;
    console.log('❌ 串口已断开');
    log('info', '串口已断开');
  }
}

/**
 * 启动命令接收服务（需服务已启动）
 */
function startCommandServer() {
  console.log('命令接收服务已启动');
  log('info', '命令接收服务已启动');
}

/**
 * 停止命令接收服务（需服务已停止）
 */
function stopCommandServer() {
  console.log('命令接收服务已停止');
  log('info', '命令接收服务已停止');
}

// ====================== 9. 启动服务 ======================
async function startService() {
  await loadConfig();

  // 启动命令服务（若初始状态为运行）
  if (config.isRunning) {
    await connectSerial();
  }

  // 启动HTTP服务
  app.listen(config.servicePort, '0.0.0.0', () => {
    const getLocalIP = () => {
      const interfaces = os.networkInterfaces();
      for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
          if (iface.family === 'IPv4' && !iface.internal) {
            return iface.address;
          }
        }
      }
      return 'localhost';
    };

    console.log(`🌐 服务已启动，访问地址：http://${getLocalIP()}:${config.servicePort}`);
    console.log(`🔌 初始COM端口：${config.comPort}，波特率：${config.baudRate}`);
    console.log(`📌 管理界面地址：http://${getLocalIP()}:${config.servicePort}/admin`);
    log('info', `服务已启动，访问地址：http://${getLocalIP()}:${config.servicePort}`);
  });
}

// 启动服务（捕获全局错误）
startService().catch(err => {
  console.error('服务启动失败:', err);
  log('error', `服务启动失败: ${err.message}`);
  process.exit(1);
});

// ====================== 10. 加载配置文件 ======================
async function loadConfig() {
  try {
    const data = await fs.readFile(CONFIG_PATH, 'utf8');
    config = { ...config, ...JSON.parse(data) }; // 合并默认值与文件配置
    console.log('配置文件加载成功:', config);
    log('info', '配置文件加载成功');
  } catch (err) {
    console.log('配置文件不存在，使用默认配置:', config); // 确保默认配置生效
    log('info', '配置文件不存在，使用默认配置');
  }
}