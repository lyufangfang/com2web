const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const { SerialPort } = require('serialport');

const router = express.Router();
const CONFIG_PATH = path.join(__dirname, '../config.json');

// 读取配置
async function readConfig() {
  const data = await fs.readFile(CONFIG_PATH, 'utf8');
  return JSON.parse(data);
}

// 写入配置
async function writeConfig(config) {
  await fs.writeFile(CONFIG_PATH, JSON.stringify(config, null, 2));
}

// 获取可用COM端口列表
router.get('/api/ports', async (req, res) => {
  try {
    const ports = await SerialPort.list();
    res.json({ success: true, ports: ports.map(p => p.path) });
  } catch (err) {
    res.status(500).json({ success: false, error: '获取COM端口失败' });
  }
});

// 获取当前配置
router.get('/api/config', async (req, res) => {
  try {
    const config = await readConfig();
    res.json({ success: true, config });
  } catch (err) {
    res.status(500).json({ success: false, error: '读取配置失败' });
  }
});

// 保存配置（COM端口/网页端口）
router.post('/api/config', async (req, res) => {
  try {
    const { comPort, servicePort } = req.body;
    let config = await readConfig();
    
    if (comPort) config.comPort = comPort;
    if (servicePort) config.servicePort = servicePort;
    
    await writeConfig(config);
    res.json({ success: true, message: '配置保存成功' });
  } catch (err) {
    res.status(500).json({ success: false, error: '保存配置失败' });
  }
});

// 控制服务启停
router.post('/api/service/:action(start|stop)', async (req, res) => {
  try {
    // 这里需要调用你原有服务的启停逻辑（需暴露接口）
    // 示例：假设原服务有 start()/stop() 方法
    const action = req.params.action;
    if (action === 'start') {
      // 启动服务逻辑...
      res.json({ success: true, message: '服务已启动' });
    } else {
      // 停止服务逻辑...
      res.json({ success: true, message: '服务已停止' });
    }
  } catch (err) {
    res.status(500).json({ success: false, error: '服务控制失败' });
  }
});

module.exports = router;